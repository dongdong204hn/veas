//
//  ChooseViewController.h
//  VOA
//
//  Created by song zhao on 12-2-2.
//  Copyright (c) 2012年 buaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ChooseViewController : UIViewController

@end
