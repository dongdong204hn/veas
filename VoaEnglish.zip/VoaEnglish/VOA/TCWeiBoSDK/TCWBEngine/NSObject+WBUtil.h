//
//  NSObject+WBUtil.h
//  WiressSDKDemo
//
//  Created by wang ying on 12-8-13.
//  Copyright (c) 2012年 bysft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (WBUtil)

@end


@interface NSString (WBRequest)

- (NSString *)URLEncodedString;
- (NSString *)URLEncodedStringWithCFStringEncoding:(CFStringEncoding)encoding;

@end