//
//  UINoteView.h
//  PlaceApp
//
//  Created by 北京市海淀区 guosong on 12-8-24.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UINoteView : UIView {
    
}

- (void)showNoteView;
- (void)hidenView;
- (CGSize) setNoteText:(NSString*) aText;
@end
