//
//  contractibleImageView.h
//  TCWeiBoSDKDemo
//
//  Created by zzz on 8/28/12.
//  Copyright (c) 2012 bysft. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface contractibleImageView : UIImageView {
    UIButton        *deledateBtn;
}

@property (nonatomic, retain)UIButton        *deledateBtn;
@end
