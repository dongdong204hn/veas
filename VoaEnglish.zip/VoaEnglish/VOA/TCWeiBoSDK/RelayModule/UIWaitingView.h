//
//  UIWaitingView.h
//  PlaceApp
//
//  Created by 北京市海淀区 guosong on 12-8-23.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIWaitingView : UIView {
    
}

- (void) startActivityLoading;
- (void) endActivityLoading;

- (void) setTitle:(NSString*) strTitle;

@end
