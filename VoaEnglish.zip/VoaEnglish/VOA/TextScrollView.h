//
//  TextScrollViewDelegate.h
//  VOA
//
//  Created by song zhao on 12-2-19.
//  Copyright (c) 2012年 buaa. All rights reserved.
//

/**
 *  custom UIScrollView that push the touch event to super view
 */
@interface TextScrollView : UIScrollView

@end
