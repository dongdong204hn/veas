//
//  UIImage+SplitImageIntoTwoParts.h
//  VOA
//  realize open door animation 
//  Created by Terry Lin on 12-5-11.
//  Copyright (c) 2012年 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>

/**
 *
 */
@interface UIImage (SplitImageIntoTwoParts)

+ (NSArray*)splitImageIntoTwoParts:(UIImage*)image;

@end
