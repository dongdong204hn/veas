//
//  MyNavigationBar.h
//  VOA
//
//  Created by song zhao on 12-3-9.
//  Copyright (c) 2012年 buaa. All rights reserved.
//

/**
 *
 */
@interface MyNavigationBar : UINavigationBar
{

}

@end
