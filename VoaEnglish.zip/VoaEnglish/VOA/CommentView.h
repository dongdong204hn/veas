//
//  CommentView.h
//  VOA
//
//  Created by zhao song on 13-5-8.
//  Copyright (c) 2013年 buaa. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CommentView : UIView

@property (nonatomic, retain) UITableView *commTableView;

@end
