//
//  VoaImageCell.h
//  VOA
//  iPad界面的加载图片视图
//  Created by song zhao on 12-6-25.
//  Copyright (c) 2012年 buaa. All rights reserved.
//

/**
 *
 */
@interface VoaImageCell : UITableViewCell
{
    UIImageView *myImage;
}

@property (nonatomic,retain) IBOutlet UIImageView *myImage;

@end
