//
//  ColorPickerControllerViewController.h
//  VOA
//
//  Created by zhao song on 13-5-8.
//  Copyright (c) 2013年 buaa. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "InfColorPickerController.h"

@interface ColorPickerControllerViewController : UIViewController < InfColorPickerControllerDelegate >

@end
