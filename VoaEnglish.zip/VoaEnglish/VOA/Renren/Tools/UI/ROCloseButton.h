//
//  ROCloseButton.h
//  RenrenSDKDemo
//
//  Created by Winston on 11-8-24.
//  Copyright 2011年 Renren Inc. All rights reserved.
//  - Powered by Team Pegasus. -
//

#import <UIKit/UIKit.h>

@interface ROCloseButton : UIButton

+(ROCloseButton *)closeButtonForRODialog;
@end
