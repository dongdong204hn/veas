//
//  myTabBar.h
//  VOA
//
//  Created by song zhao on 12-3-8.
//  Copyright (c) 2012年 buaa. All rights reserved.
//

/**
 *
 */
@interface myTabBar : UITabBar

@end
